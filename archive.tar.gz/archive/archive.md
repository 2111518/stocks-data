### Archive
archive.tar.gz
- `less-data.py` 取得 constituents.csv 的股票代碼，可以搭配 `sp-simulate.py` 或其他程式使用
- `sp-simulate.py` 模擬計算標普500指數
- `stock-period.py` 可以取得指定時間內標普500公司的收盤價  
- `stock-latest.py` 可以取得最近一次的標普500公司的收盤價
- `link-data.c` 可以把股票代碼、公司名稱以及GICS放到 `out.txt` 中  
- `info.c` 可以將資料行數，最長的資料字元數，以及個別資料的最長字元數放入`info.txt`   
- `sort.c` 會把 `out.txt` 的內容進行排序(根據字母以及GICS)，將結果放入`sort.txt`
- `gics-sort.c` 大部分和 sort.c 一樣，但會根據使用者的輸入進行篩選，將結果放入`gics-sort.txt`

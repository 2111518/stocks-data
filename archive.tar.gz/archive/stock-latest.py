import yfinance as yf
import pandas as pd
from pathlib import Path

def get_tickers_info_from_csv(filepath: Path) -> pd.DataFrame:
    """從 constituents.csv 讀取 Symbol, Security, GICS Sector"""
    if not filepath.exists():
        print(f"❌ 檔案 '{filepath}' 找不到，請確認檔案是否存在。")
        return pd.DataFrame()

    try:
        df = pd.read_csv(filepath, usecols=['Symbol', 'Security', 'GICS Sector'])
        df['Symbol'] = df['Symbol'].str.upper()
        return df
    except Exception as e:
        print(f"❌ 讀取檔案時發生錯誤: {e}")
        return pd.DataFrame()

def fetch_latest_prices(ticker_df: pd.DataFrame) -> pd.DataFrame:
    """使用 yfinance 抓取股票最新收盤價，包含 GICS Sector"""
    tickers = ticker_df['Symbol'].tolist()
    stocks = yf.Tickers(" ".join(tickers))

    results = []
    for _, row in ticker_df.iterrows():
        ticker = row['Symbol']
        name = row['Security']
        sector = row['GICS Sector']
        try:
            stock = stocks.tickers[ticker]
            hist = stock.history(period="1d")
            if not hist.empty:
                price = hist["Close"].iloc[-1]
                date = hist.index[-1].strftime("%Y-%m-%d")
                results.append([ticker, name, sector, price, date])
            else:
                print(f"⚠️ 無法獲取 {ticker} 的歷史數據。")
        except Exception as e:
            print(f"❌ 取得 {ticker} 的數據時發生錯誤: {e}")
    return pd.DataFrame(results, columns=["Ticker", "Company Name", "GICS Sector", "Price", "Date"])

def main():
    filepath = Path("./constituents.csv")
    ticker_df = get_tickers_info_from_csv(filepath)

    if ticker_df.empty:
        print("❌ 沒有讀取到任何股票資訊，程式結束。")
        return

    df = fetch_latest_prices(ticker_df)
    df.to_csv("stock-close-latest.csv", index=False)
    print("📄 資料已儲存到 stock-close-latest.csv")

if __name__ == "__main__":
    main()

